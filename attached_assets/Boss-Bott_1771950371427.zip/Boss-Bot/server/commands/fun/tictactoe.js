const TicTacToe = require('../lib/tictactoe');

// Store games globally
const games = {};

async function tictactoeCommand(sock, chatId, senderId, mentionedJids, message, args) {
    try {
        // Check if player is already in a game
        if (Object.values(games).find(room => 
            room.id.startsWith('tictactoe') && 
            [room.game.playerX, room.game.playerO].includes(senderId)
        )) {
            await sock.sendMessage(chatId, { 
                text: '❌ You are still in a game. Type *surrender* to quit.' 
            });
            return;
        }

        // Look for existing room
        let room = Object.values(games).find(room => 
            room.state === 'WAITING' && room.x === chatId
        );

        if (room && room.game.playerX !== senderId) {
            // Join existing room - allow joining with just .ttt
            room.o = chatId;
            room.game.playerO = senderId;
            room.state = 'PLAYING';
            
            // Set timeout for game
            room.timeout = setTimeout(() => {
                if (games[room.id]) {
                    sock.sendMessage(room.x, { text: '⏰ TicTacToe game timed out!' });
                    if (room.x !== room.o) {
                        sock.sendMessage(room.o, { text: '⏰ TicTacToe game timed out!' });
                    }
                    delete games[room.id];
                }
            }, 300000); // 5 minute timeout

            const arr = room.game.render().map(v => ({
                'X': '❎',
                'O': '⭕',
                '1': '1️⃣',
                '2': '2️⃣',
                '3': '3️⃣',
                '4': '4️⃣',
                '5': '5️⃣',
                '6': '6️⃣',
                '7': '7️⃣',
                '8': '8️⃣',
                '9': '9️⃣',
            }[v]));

            const str = `
🎮 *TicTacToe Game Started!*

Waiting for @${room.game.currentTurn.split('@')[0]} to play...

${arr.slice(0, 3).join('')}
${arr.slice(3, 6).join('')}
${arr.slice(6).join('')}

▢ *Room ID:* ${room.id}
▢ *Rules:*
• Make 3 rows of symbols vertically, horizontally or diagonally to win
• Type a number (1-9) to place your symbol
• Type *surrender* to give up
`;

            // Send message only once to the group
            const { channelInfo } = require("../lib/messageConfig");
            await sock.sendMessage(chatId, { 
                text: str,
                mentions: [room.game.currentTurn, room.game.playerX, room.game.playerO],
                ...channelInfo
            });

        } else {
            // Create new room
            room = {
                id: 'tictactoe-' + (+new Date),
                x: chatId,
                o: '',
                game: new TicTacToe(senderId, 'o'),
                state: 'WAITING'
            };

            await sock.sendMessage(chatId, { 
                text: `⏳ *Waiting for opponent*\nType *.ttt* to join the game!`
            });

            games[room.id] = room;
        }

    } catch (error) {
        console.error('Error in tictactoe command:', error);
        await sock.sendMessage(chatId, { 
            text: '❌ Error starting game. Please try again.' 
        });
    }
}

async function handleTicTacToeMove(sock, chatId, senderId, mentionedJids, message, args) {
    try {
        const text = args && args.length > 0 ? args.join(' ').trim() : '';
        
        // Find player's game
        const room = Object.values(games).find(room => 
            room.id.startsWith('tictactoe') && 
            [room.game.playerX, room.game.playerO].includes(senderId) && 
            room.state === 'PLAYING'
        );

        if (!room) return;

        const isSurrender = /^(surrender|give up|.surrender|.stop)$/i.test(text);
        
        if (!isSurrender && !/^[1-9]$/.test(text)) {
            return;
        }

        // Allow surrender at any time if in room
        if (isSurrender) {
            // Find the room where the sender is playing
            const playerRoom = Object.values(games).find(room => 
                room.id.startsWith('tictactoe') && 
                [room.game.playerX, room.game.playerO].includes(senderId)
            );
            
            if (!playerRoom) return;

            // Set the winner to the opponent of the surrendering player
            const winner = senderId === playerRoom.game.playerX ? playerRoom.game.playerO : playerRoom.game.playerX;
            
            // Send a surrender message
            await sock.sendMessage(chatId, { 
                text: `🏳️ @${senderId.split('@')[0]} has surrendered! @${winner.split('@')[0]} wins the game!`,
                mentions: [senderId, winner]
            });
            
            // Delete the game immediately after surrender
            if (playerRoom.timeout) clearTimeout(playerRoom.timeout);
            delete games[playerRoom.id];
            return;
        }

        if (senderId !== room.game.currentTurn) {
            await sock.sendMessage(chatId, { 
                text: '❌ Not your turn!' 
            });
            return;
        }

        let gameStatus;
        if (winner) {
            gameStatus = `🎉 @${winner.split('@')[0]} wins the game!`;
        } else if (isTie) {
            gameStatus = `🤝 Game ended in a draw!`;
        } else {
            gameStatus = `🎲 Turn: @${room.game.currentTurn.split('@')[0]} (${senderId === room.game.playerX ? '❎' : '⭕'})`;
        }

        const str = `
🎮 *TicTacToe Game*

${gameStatus}

${arr.slice(0, 3).join('')}
${arr.slice(3, 6).join('')}
${arr.slice(6).join('')}

▢ Player ❎: @${room.game.playerX.split('@')[0]}
▢ Player ⭕: @${room.game.playerO.split('@')[0]}

${!winner && !isTie ? '• Type a number (1-9) to make your move\n• Type *surrender* to give up' : ''}
`;

        const mentions = [
            room.game.playerX, 
            room.game.playerO,
            ...(winner ? [winner] : [room.game.currentTurn])
        ];

        const { channelInfo } = require("../lib/messageConfig");
        await sock.sendMessage(room.x, { 
            text: str,
            mentions: mentions,
            ...channelInfo
        });

        if (room.x !== room.o) {
            await sock.sendMessage(room.o, { 
                text: str,
                mentions: mentions,
                ...channelInfo
            });
        }

        if (winner || isTie) {
            if (room.timeout) clearTimeout(room.timeout);
            delete games[room.id];
        }

    } catch (error) {
        console.error('Error in tictactoe move:', error);
    }
}

module.exports = {
    tictactoeCommand,
    handleTicTacToeMove
};
